 // Function to toggle sidebar visibility on mobile
 function toggleSidebar() {
    var sidebar = document.getElementById('sidebar-menu');
    var overlay = document.getElementById('overlay');
    
    // Toggle the sidebar and overlay
    sidebar.classList.toggle('show-sidebar');
    overlay.style.display = sidebar.classList.contains('show-sidebar') ? 'block' : 'none';
}

// Close sidebar if clicking outside of it (on overlay)
function closeSidebar() {
    var sidebar = document.getElementById('sidebar-menu');
    var overlay = document.getElementById('overlay');
    
    // Remove the show-sidebar class and hide the overlay
    if (sidebar.classList.contains('show-sidebar')) {
        sidebar.classList.remove('show-sidebar');
        overlay.style.display = 'none';
    }
}

// Event listeners for hamburger menu and overlay
document.getElementById('hamburger-menu').addEventListener('click', toggleSidebar);
document.getElementById('overlay').addEventListener('click', closeSidebar);