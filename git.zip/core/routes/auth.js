const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const dotenv = require('dotenv');

dotenv.config();

// Hiển thị trang đăng ký
router.get('/register', (req, res) => {
  res.render('user/register', { message: null });
});

// Xử lý đăng ký người dùng
router.post('/register', (req, res) => {
  const { username, password } = req.body;

  db.query('SELECT * FROM users WHERE username = ?', [username], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
    }
    if (result.length > 0) {
      return res.render('user/register', { message: 'Username đã tồn tại' });
    }

    const hashedPassword = bcrypt.hashSync(password, 8);
    db.query('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, hashedPassword, 1], (err) => {
      if (err) {
        return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
      }
      res.redirect('/auth/login');
    });
  });
});

// Hiển thị trang đăng nhập
router.get('/login', (req, res) => {
  res.render('user/login', { message: null });
});

// Xử lý đăng nhập
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.query('SELECT * FROM users WHERE username = ?', [username], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
    }
    if (result.length === 0) {
      return res.render('user/login', { message: 'Tên đăng nhập hoặc mật khẩu không đúng' });
    }

    const user = result[0];
    const passwordIsValid = bcrypt.compareSync(password, user.password);
    if (!passwordIsValid) {
      return res.render('user/login', { message: 'Tên đăng nhập hoặc mật khẩu không đúng' });
    }

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
      expiresIn: 86400,
    });

    res.cookie('token', token, { httpOnly: true });
    res.redirect('/user/dashboard');
  });
});

// Xử lý đăng xuất
router.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/auth/login');
});

module.exports = router;
