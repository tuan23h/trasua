const express = require('express');
const db = require('../config/db');
const router = express.Router();
const { checkToken } = require('../middleware/auth');

// Route cho trang dashboard - hiển thị danh sách bài viết
router.get('/dashboard', checkToken, (req, res) => {
    db.query('SELECT id, title, image, content, likes, category FROM posts', (err, posts) => {
        if (err) {
            return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
        }

        res.render('user/home', { posts });
    });
});

// Route để hiển thị chi tiết bài viết
router.get('/posts/:id', checkToken, (req, res) => {
    const postId = req.params.id;

    db.query('SELECT * FROM posts WHERE id = ?', [postId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Bài viết không tồn tại' });
        }

        const post = results[0];
        res.render('user/post', { post }); // Render view cho bài viết
    });
});

module.exports = router;
