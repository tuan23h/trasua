const express = require('express');
const router = express.Router();
const db = require('../config/db');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');

// Cấu hình lưu trữ file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
      cb(null, '../plate/public/uploads'); // Lưu file vào thư mục public/uploads
  },
  filename: (req, file, cb) => {
      cb(null, Date.now() + path.extname(file.originalname)); // Đặt tên file unique
  }
});

const upload = multer({ storage }); // Thư mục lưu hình ảnh

// Middleware kiểm tra quyền
function checkRole(minRole) {
  return (req, res, next) => {
    const token = req.cookies.token;
    if (!token) {
      return res.redirect('/auth/login');
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
        return res.redirect('/auth/login');
      }

      db.query('SELECT * FROM users WHERE id = ?', [decoded.id], (err, result) => {
        if (err || result.length === 0 || result[0].role < minRole) {
          return res.status(403).json({ message: 'Bạn không có quyền truy cập trang này' });
        }

        req.user = result[0];
        next();
      });
    });
  };
}

// Hiển thị trang quản lý bài viết
router.get('/posts', checkRole(127), (req, res) => {
  db.query('SELECT * FROM posts', (err, posts) => {
    if (err) {
      return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
    }
    res.render('admin/admin_posts', { posts });
  });
});

// Hiển thị trang thêm bài viết mới
router.get('/posts/new', checkRole(127), (req, res) => {
  res.render('admin/new_post');
});

// Xử lý thêm bài viết
router.post('/posts/create', upload.single('image'), (req, res) => {
  const { title, content } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : null; // Đường dẫn đến hình ảnh

  // Lưu bài viết vào cơ sở dữ liệu
  db.query('INSERT INTO posts (title, content, image) VALUES (?, ?, ?)', [title, content, imagePath], (err) => {
    if (err) {
      return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
    }
    res.redirect('/admin/posts');
  });
});

// Hiển thị trang chỉnh sửa bài viết
router.get('/posts/edit/:id', checkRole(127), (req, res) => {
  const postId = req.params.id;

  db.query('SELECT * FROM posts WHERE id = ?', [postId], (err, post) => {
    if (err || post.length === 0) {
      return res.status(404).json({ message: 'Bài viết không tồn tại' });
    }
    res.render('admin/edit_post', { post: post[0] });
  });
});

// Xử lý chỉnh sửa bài viết
router.post('/posts/:id/edit', upload.single('image'), (req, res) => {
  const postId = req.params.id;
  const { title, content } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : null; // Đường dẫn đến hình ảnh
  // Cập nhật bài viết trong cơ sở dữ liệu
  db.query('UPDATE posts SET title = ?, content = ?, image = ? WHERE id = ?', [title, content, imagePath, postId], (err) => {
      if (err) {
          return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
      }
      res.redirect('/admin/posts'); // Chuyển hướng đến dashboard
  });
});

// Xử lý xóa bài viết
router.post('/posts/delete/:id', checkRole(127), (req, res) => {
  const postId = req.params.id;

  db.query('DELETE FROM posts WHERE id = ?', [postId], (err) => {
    if (err) {
      return res.status(500).json({ message: 'Lỗi cơ sở dữ liệu' });
    }
    res.redirect('/admin/posts');
  });
});

module.exports = router;
